from django.urls import path, include
from .views import hello_pages, CityDetailView

urlpatterns = [
    path('', hello_pages),
    path('pages/detail/5', CityDetailView.as_view(), name='city_detail'),

]

