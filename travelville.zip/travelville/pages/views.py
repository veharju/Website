from django.shortcuts import render
# Create your views here.
from django.views.generic import DetailView

from pages.models import City


def hello_pages(request):
    return render(request, 'home.html')


class CityDetailView(DetailView):
    model = City
    context_object_name = 'city'
    template_name = 'city_detail.html'
    pk_url_kwarg = 'pk'
    query_pk_and_slug = True
    slug_field = 'city_slug'
    slug_url_kwarg = 'city_slug'


